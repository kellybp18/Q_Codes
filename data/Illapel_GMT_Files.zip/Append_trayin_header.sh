#!/bin/bash
#
	infile='Evt_stn_list.txt'

	while read line; do
		cleanname=$(echo $line | cut -f2 -d'/')
		ofile=$cleanname'.'tray.in
		cutin=$(echo $cleanname | cut -f1 -d'.')
	
		cat Tra_rays.in_headr $cleanname > $ofile
		cat $ofile > $cleanname
		rm  $ofile
	
	done < $infile