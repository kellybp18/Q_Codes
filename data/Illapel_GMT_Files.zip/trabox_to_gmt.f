C
C Program to write trabox output data to .gmt
C files for each event-station pair
C
	Program trabox_to_gmt
C
	Character * 80 ofile
	Character * 23 convtest, charcheck
C
	integer istat
C
C
C
		Write(6,*) 'What is the name of the output file?'
			Read(5,*,iostat=istat) ofile
			Write(6,*) istat
C
		Open(unit = 1, file = 'Tra_details.out', status = 'old')
		Rewind 1
C
		Open(unit = 2, file = 'Tra_summary.out', status = 'old')
		Rewind 2
C
		Open(unit = 3, file = ofile, status = 'replace')
		Rewind 3
C
		Read(2,8) ttime, startx, starty, startz, endx, endy, endz
 8		Format(5x,f9.4,1x,3(f8.3,1x),27x,3(f9.3,1x))
		if(endz .lt. 0) then
			endz = 0.000
		end if
		startlon = (startx/95.3127) - 73
		startlat = (starty/111.1949) - 34
		endlon = (endx/95.3127) - 73
		endlat = (endy/111.1949) - 34
		Write(3,9) startlon, startlat, startz
 9		Format(f9.5,1x,f9.5,1x,f9.5)
C
		lns = 0
		do 
			Read(1,*,iostat=istat)
			If(istat.EQ.0) then
				lns = lns + 1 
			else
				exit
			end if
		end do
		Rewind 1
C
		linenum = 0
		do l = 1,lns
			Read(1,13,iostat=istat) convtest
 13			Format(a23)
C			Write(6,*) istat, l, convtest
			if(convtest .eq. '    Convergence Test   ') then
				linenum = l
			end if
		end do
		Rewind 1
C
		if(linenum .eq. 0) then
			linenum = 52
		end if
C
		do i = 1,linenum+5
			Read(1,*)
		end do
C
		do
			Read(1,*)
			Read(1,10) istep
 10			Format(100x,i3)
			Read(1,*)
			Read(1,*)
			Read(1,11) xlon
 11			Format(23x,f9.5)
 			Read(1,11) ylat
 			Read(1,11) z
 			do k = 1,14
				Read(1,*)
			end do
			if(istep .ne. 0) then
				alon = (xlon/95.3127) - 73
				alat = (ylat/111.1949) - 34
				Write(3,9) alon, alat, z
			end if
			Read(1,13) charcheck
			if(charcheck .ne. '   Current W,F,h and t ') then
				exit
			end if
		end do
C
		Write(3,12) endlon, endlat, endz, ttime
 12		Format(3(f9.5,1x),2x,f9.4)
C
		Rewind 1
		Close (unit=1)
		Rewind 2
		Close (unit=2)
C
C
C
	Stop
	End
				
		
		
		