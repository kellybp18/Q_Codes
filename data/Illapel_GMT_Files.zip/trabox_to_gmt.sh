#!/bin/bash
#
	infile='Evt_stn_list.txt'
	
	while read line; do
		filename=$line
		echo $filename
		/Users/bpk/Documents/BPK_Masters_2019/raytrace/trabox <<- EOF
			$filename
		EOF
#
		cutname=$(echo $line | cut -f1 -d'.')
		ofile=$cutname'.gmt'
		./trabox_to_gmt <<- EOF
			$ofile
		EOF
	done < $infile
		
